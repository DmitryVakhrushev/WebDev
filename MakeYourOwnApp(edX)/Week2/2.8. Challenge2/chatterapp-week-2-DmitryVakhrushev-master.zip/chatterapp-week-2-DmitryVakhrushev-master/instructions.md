HTML
- HTMl doc
- head (title etc)
- body, Chsection tag, h1 title
- h2 regular and favorite channels
- Channel strong + date small
- break element
- h1 for channel title
- button for toggling favorite
- messages: h2 for name, p for message, small for time
- break element
- input element
- send button
  
CSS
inline tag
- all elements font-family
- h1 color
- h2 color, smaller
- p backgournd color
- button: background color, color, text-transform, font-size